icon_shop = I(_class='fa fa-shopping-cart')
icon_edit = I(_class='fa fa-pencil fa-lg')
icon_delete = I(_class='fa fa-times fa-lg')
