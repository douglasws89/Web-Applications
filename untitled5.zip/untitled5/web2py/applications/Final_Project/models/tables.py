#########################################################################
## Define your tables below; for example
##
## >>> db.define_table('mytable',Field('myfield','string'))
##
## Fields can be 'string','text','password','integer','double','boolean'
##       'date','time','datetime','blob','upload', 'reference TABLENAME'
## There is an implicit 'id integer autoincrement' field
## Consult manual for more options, validators, etc.
##
## More API examples for controllers:
##
## >>> db.mytable.insert(myfield='value')
## >>> rows=db(db.mytable.myfield=='value').select(db.mytable.ALL)
## >>> for row in rows: print row.id, row.myfield
#########################################################################


db.define_table('post',
                Field('author', db.auth_user, default=auth.user_id),
                Field('image', 'upload'),
                Field('meal', 'string', requires=IS_IN_SET(['Breakfast', 'Lunch', 'Dinner', 'Other'])),
                Field('title', 'string'),
                Field('caption', 'text'),
                Field('country', 'string'),
                Field('estate', 'string'),
                Field('city', 'string'),
                Field('ethnicity', 'string'),
                Field('age', 'string', requires=IS_IN_SET(['0-20', '20-40', '40-60', '60+'])),
                Field('income', 'string', requires=IS_IN_SET(['Lower Class', 'Working Class', 'Middle Class', 'Upper Class'])),
                Field('gender', 'string', requires=IS_IN_SET(['Male', 'Female', 'Transgender', 'Other'])),
                Field('posted_on', 'datetime', default=request.utcnow),
                )

db.define_table('filters',
                Field('author', db.auth_user, default=auth.user_id),
                Field('country', 'string'),
                Field('estate', 'string'),
                Field('city', 'string'),
                Field('ethnicity', 'string'),
                Field('age', 'string', requires=IS_IN_SET(['0-20', '20-40', '40-60', '60+'])),
                Field('meal', 'string', requires=IS_IN_SET(['Breakfast', 'Lunch', 'Dinner', 'Other'])),
                Field('income', 'string', requires=IS_IN_SET(['Lower Class', 'Working Class', 'Middle Class', 'Upper Class'])),
                Field('gender', 'string', requires=IS_IN_SET(['Male', 'Female', 'Transgender', 'Other']))
                )

db.define_table('user_profile',
                Field('author', db.auth_user, default=auth.user_id),
                Field('profile_picture','upload'),
                Field('bio','text')
                )

db.post.id.readable = db.post.id.writable = False
db.user_profile.id.readable = db.user_profile.id.writable = False
db.post.posted_on.readable = db.post.posted_on.writable = False
db.post.author.readable = db.post.author.writable = False
db.user_profile.author.readable = db.user_profile.author.writable = False