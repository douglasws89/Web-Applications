/**
 * Created by Douglas on 11/30/2015.
 */
(function($){
    $(document).ready(function () {

        $(".pagination").customPaginate({
            itemsToPaginate: ".post"
        });
    });
}(jQuery));