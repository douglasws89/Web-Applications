def index():
    return dict()

def get_table():
    el_list = db().select(db.posts.ALL).as_list()
    return response.json(dict(el_list=el_list))