# -*- coding: utf-8 -*-
# this file is released under public domain and you can use without limitations

#########################################################################
## This is a sample controller
## - index is the default action of any application
## - user is required for authentication and authorization
## - download is for downloading files uploaded in the db (does streaming)
#########################################################################

from datetime import datetime
from datetime import timedelta



def index():
    return dict()


def main():
    """
     Populates the main page. Requestes var containing the filters
     chosen by user and returns the information from the database.
    """
    db.filters.update_or_insert(author=auth.user_id)
    list_dict = {'meal': fields_func('meal'),
                 'ethnicity': fields_func('ethnicity'),
                 'country': fields_func('country'),
                 'age': fields_func('age'),
                 'income': fields_func('income'),
                 'gender': fields_func('gender')
                 }
    filter = db((db.filters.author == auth.user_id)).select(db.filters.ALL)
    posts_list = db((db.filters.author == auth.user_id) &
                    (
                        ((db.filters.country == db.post.country) | (db.filters.country == None)) &
                        ((db.filters.meal == db.post.meal) | (db.filters.meal == None)) &
                        ((db.filters.age == db.post.age) | (db.filters.age == None)) &
                        ((db.filters.income == db.post.income) | (db.filters.income == None)) &
                        ((db.filters.gender == db.post.gender) | (db.filters.gender == None)) &
                        ((db.filters.ethnicity == db.post.ethnicity) | (db.filters.ethnicity == None))
                    )
                    ).select(db.post.ALL, orderby=~db.post.posted_on)
    form = SQLFORM(db.post)
    user_profile = db().select(db.user_profile.ALL)
    return dict(posts_list=posts_list, form=form, list_dict=list_dict, filter=filter, user_profile=user_profile, pretty_month=pretty_month, pretty_min=pretty_min)


@auth.requires_login()
def my_posts():
    """
    Populates the profile page. Selects from the databasis only the
    information regarding the specific user.
    """
    db.user_profile.update_or_insert(author=auth.user_id)
    profile = auth.user_id
    if (profile is None):
        session.flash = T('Please Log in!')
        redirect(URL('default', 'main'))
    user_profile = db((db.user_profile.author == request.args(0))).select(db.user_profile.ALL)
    posts_list = db((db.post.author == request.args(0))).select(db.post.ALL)
    a = request.args(0)
    print a
    print auth.user_id
    form = SQLFORM(db.user_profile)
    form_post = SQLFORM(db.post)
    return dict(user_profile=user_profile, form=form, posts_list=posts_list, form_post=form_post, a=a)


@auth.requires_login()
@auth.requires_signature()
def profile_edit():
    """
    Populates the edit profile. Passing a form with pre-filled entries
    from the user.
    """
    db.user_profile.update_or_insert(author=auth.user_id)
    user_profile = db((db.user_profile.author == auth.user_id)).select(db.user_profile.ALL)
    profile = db.user_profile(request.args(0))
    if profile is None:
        session.flash = T('No such profile')
        redirect(URL('default', 'my_posts', args=[auth.user_id]))
    form = SQLFORM(db.user_profile, record=profile)
    if form.process().accepted:
        session.flash = T('The profile was edited')
        redirect(URL('default', 'my_posts', args=[auth.user_id]))
    return dict(form=form, user_profile=user_profile)


@auth.requires_login()
@auth.requires_signature()
def create_post():
    """
    Returns a form that allows user to create a form. Plus profile
    information to populate the page.
    """
    db.user_profile.update_or_insert(author=auth.user_id)
    user_profile = db((db.user_profile.author == auth.user_id)).select(db.user_profile.ALL)
    form = SQLFORM(db.post)
    if form.process().accepted:
        session.flash = T('A new post was created')
        redirect(URL('default', 'main'))
    return dict(user_profile=user_profile, form=form)


@auth.requires_login()
@auth.requires_signature()
def post_edit():
    """
    Populates post_edit page with user information and a form
    pre-filled with information about specific post.
    """
    db.user_profile.update_or_insert(author=auth.user_id)
    user_profile = db((db.user_profile.author == auth.user_id)).select(db.user_profile.ALL)
    post = db.post(request.args(0))
    if post is None:
        session.flash = T('No such post')
        redirect(URL('default', 'my_posts', args=[auth.user_id]))
    form = SQLFORM(db.post, record=post)
    if form.process().accepted:
        session.flash = T('The post was edited')
        redirect(URL('default', 'my_posts', args=[auth.user_id]))
    return dict(form=form, user_profile=user_profile)


@auth.requires_login()
@auth.requires_signature()
def delete_post():
    """
    Lets user delete post from database
    """
    db(db.post.id == int(request.args(0))).delete()
    session.flash = T('The post was deleted')
    redirect(URL('default', 'my_posts', args=[auth.user_id], user_signature=True))


def maps():
    """
    Populates the MAps page. Requests information from database to
    populate the map. Returns the information according to what the
    user chose to filter.
    """
    db.user_profile.update_or_insert(author=auth.user_id)
    list_dict = {'meal': fields_func('meal'),
                 'ethnicity': fields_func('ethnicity'),
                 'country': fields_func('country'),
                 'age': fields_func('age'),
                 'income': fields_func('income'),
                 'gender': fields_func('gender')
                 }
    filter = db().select(db.post.ALL)
    posts_list = db((db.filters.author == auth.user_id) &
                    (
                        ((db.filters.country == db.post.country) | (db.filters.country == None)) &
                        ((db.filters.meal == db.post.meal) | (db.filters.meal == None)) &
                        ((db.filters.age == db.post.age) | (db.filters.age == None)) &
                        ((db.filters.income == db.post.income) | (db.filters.income == None)) &
                        ((db.filters.gender == db.post.gender) | (db.filters.gender == None)) &
                        ((db.filters.ethnicity == db.post.ethnicity) | (db.filters.ethnicity == None))
                    )
                    ).select(db.post.ALL)
    form = SQLFORM(db.post)
    return dict(posts_list=posts_list, form=form, list_dict=list_dict, filter=filter)


def filter_option():
    """
    Gets information about the filters chose from the user and updates
    the fields of the table with the new filters selected or, if no
    filters are selected, populates the field(s) with None.
    """
    db.filters.update_or_insert(author=auth.user_id)

    filter = request.vars.filter
    if (filter == "Select..."):
        filter = None
    if(request.vars.field == "country"):
        db(db.filters.author == auth.user_id).update(country=filter)
    elif(request.vars.field == "ethnicity"):
        db(db.filters.author == auth.user_id).update(ethnicity=filter)
    elif(request.vars.field == "meal"):
        db(db.filters.author == auth.user_id).update(meal=filter)
    elif(request.vars.field == "age"):
        db(db.filters.author == auth.user_id).update(age=filter)
    elif(request.vars.field == "gender"):
        db(db.filters.author == auth.user_id).update(gender=filter)
    elif(request.vars.field == "income"):
        db(db.filters.author == auth.user_id).update(income=filter)
    else:
        db(db.filters.author == auth.user_id).update(country=filter)
        db(db.filters.author == auth.user_id).update(ethnicity=filter)
        db(db.filters.author == auth.user_id).update(meal=filter)
        db(db.filters.author == auth.user_id).update(age=filter)
        db(db.filters.author == auth.user_id).update(gender=filter)
        db(db.filters.author == auth.user_id).update(income=filter)

    return "ok"


def fields_func(elemento):
    """
    Generates the information to populate the selectmenu of the filters.
    If new information is added it appears in the select menu. If the
    information is already there, prevents it from duplicating.
    """
    list =[]
    if(elemento == 'country'):
        posts_list = db().select(db.post.ALL, orderby=db.post.country)
        for elem in posts_list:
            if(elem.country != None) & (elem.country != ""):
                list.append(elem.country)
    elif (elemento == 'meal'):
        posts_list = db().select(db.post.ALL, orderby=db.post.meal)
        for elem in posts_list:
            if(elem.meal != None) & (elem.meal != ""):
                list.append(elem.meal)
    elif (elemento == 'income'):
        posts_list = db().select(db.post.ALL, orderby=db.post.income)
        for elem in posts_list:
            if(elem.income != None) & (elem.income != ""):
                list.append(elem.income)
    elif (elemento == 'ethnicity'):
        posts_list = db().select(db.post.ALL, orderby=db.post.ethnicity)
        for elem in posts_list:
            if(elem.ethnicity != None) & (elem.ethnicity != ""):
                list.append(elem.ethnicity)
    elif (elemento == 'age'):
        posts_list = db().select(db.post.ALL, orderby=db.post.age)
        for elem in posts_list:
            if(elem.age != None) & (elem.age != ""):
                list.append(elem.age)
    elif (elemento == 'gender'):
        posts_list = db().select(db.post.ALL, orderby=db.post.gender)
        for elem in posts_list:
            if(elem.gender != None) & (elem.gender != ""):
                list.append(elem.gender)
    return duplicate(list)


def duplicate(seq):
    """
    Recieves a list and sees if there are any duplicates.
    Returns lists without duplicates
    """
    seen = set()
    seen_add = seen.add
    return [x for x in seq if not (x in seen or seen_add(x))]

def pretty_month(month):
    """
    Gets month from datetime and returns it in first three letter format.
    """
    switcher = {
        1: "Jan",
        2: "Feb",
        3: "Mar",
        4: "Apr",
        5: "May",
        6: "Jun",
        7: "Jul",
        8: "Aug",
        9: "Sep",
        10: "Oct",
        11: "Nov",
        12: "Dec",
    }
    return switcher.get(month, "nothing")


def pretty_min(min):
    """
    Gets minutes from datetime and returns it with a zero in front if
    minutes are less than 10.
    """
    if min < 10:
        return '0' + str(min)
    else:
        return min


def user():
    """
    exposes:
    http://..../[app]/default/user/login
    http://..../[app]/default/user/logout
    http://..../[app]/default/user/register
    http://..../[app]/default/user/profile
    http://..../[app]/default/user/retrieve_password
    http://..../[app]/default/user/change_password
    http://..../[app]/default/user/manage_users (requires membership in
    http://..../[app]/default/user/bulk_register
    use @auth.requires_login()
        @auth.requires_membership('group name')
        @auth.requires_permission('read','table name',record_id)
    to decorate functions that need access control
    """
    return dict(form=auth())


@cache.action()
def download():
    """
    allows downloading of uploaded files
    http://..../[app]/default/download/[filename]
    """
    return response.download(request, db)


def call():
    """
    exposes services. for example:
    http://..../[app]/default/call/jsonrpc
    decorate with @services.jsonrpc the functions to expose
    supports xml, json, xmlrpc, jsonrpc, amfrpc, rss, csv
    """
    return service()
